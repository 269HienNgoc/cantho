<?php
/**
 * Trang chủ: hệ thống chi nhánh (slider). Dữ liệu: inc/home-branches.php (Tùy biến → "Chi nhánh (Trang chủ)").
 *
 * Thẻ phẳng (không bóng): ảnh 4:3 → tên H3 → địa chỉ → hotline (tel:) → link "Chỉ đường" (URL Google Maps của chi nhánh,
 * trống thì không in). Hook JS: .js-carousel > .swiper, .carousel-prev / .carousel-next (Swiper, slidesPerView 'auto',
 * độ rộng slide bằng utility → CLS 0). 640 / 768 / 1024px: 2 / 3 / 4 thẻ; mobile hé thẻ kế (80%). Ảnh lazy.
 *
 * @package themeranghammatsgcantho
 */

defined( 'ABSPATH' ) || exit;

$rhm_items = rhm_get_home_branches();
if ( ! $rhm_items ) {
	return;
}

$rhm_count    = count( $rhm_items );
$rhm_id       = 'home-branches';
$rhm_title_id = $rhm_id . '-title';
$rhm_title    = trim( (string) get_theme_mod( 'rhm_home_branches_title', rhm_home_branches_default_title() ) ) ?: rhm_home_branches_default_title();
$rhm_eyebrow  = trim( (string) get_theme_mod( 'rhm_home_branches_eyebrow', rhm_home_branches_default_eyebrow() ) );

if ( $rhm_count > 1 && file_exists( RHM_THEME_DIR . '/dist/js/carousel.js' ) ) {
	wp_enqueue_script_module( 'rhm-carousel', RHM_THEME_URI . '/dist/js/carousel.js', array(), rhm_asset_version( 'dist/js/carousel.js' ) );
}

// Nút ‹ › giữ chỗ (invisible) từ breakpoint mà mọi thẻ đã vừa khung (< 640px luôn hé thẻ kế → luôn cần nút).
$rhm_nav_hidden = match ( $rhm_count ) {
	2       => 'sm:invisible',
	3       => 'md:invisible',
	4       => 'lg:invisible',
	default => '',
};

// Ảnh = slide − đệm phải 24px (khoảng cách giữa thẻ). Khung .swiper = khung nội dung + lề âm phải 24px.
// ≥ 1280px: (1248 + 24) / 4 − 24 = 294px. 1024–1279px: 25vw − 26px. 768–1023px: 33.33vw − 27px. 640–767px: 50vw − 28px. < 640px: 80vw − 30px.
$rhm_sizes = '(min-width: 1280px) 294px, (min-width: 1024px) calc(25vw - 26px), (min-width: 768px) calc(33.33vw - 27px), (min-width: 640px) calc(50vw - 28px), calc(80vw - 30px)';
?>
<section id="<?php echo esc_attr( $rhm_id ); ?>" class="home-branches overflow-hidden py-8 lg:py-10" aria-labelledby="<?php echo esc_attr( $rhm_title_id ); ?>">
	<div class="site-container<?php echo $rhm_count > 1 ? ' js-carousel' : ''; ?>">
		<div class="c-head">
			<div class="max-w-2xl">
				<?php if ( '' !== $rhm_eyebrow ) : ?>
					<p class="c-eyebrow"><?php echo esc_html( $rhm_eyebrow ); ?></p>
				<?php endif; ?>
				<h2 id="<?php echo esc_attr( $rhm_title_id ); ?>" class="c-h2"><?php echo esc_html( $rhm_title ); ?></h2>
			</div>
			<?php if ( $rhm_count > 1 ) : ?>
				<div class="flex gap-2 <?php echo esc_attr( $rhm_nav_hidden ); ?>">
					<button class="carousel-prev c-nav" type="button" aria-label="<?php esc_attr_e( 'Chi nhánh trước', 'themeranghammatsgcantho' ); ?>" disabled>
						<?php echo rhm_get_icon( 'chevron', 'size-5 rotate-90' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?>
					</button>
					<button class="carousel-next c-nav" type="button" aria-label="<?php esc_attr_e( 'Chi nhánh sau', 'themeranghammatsgcantho' ); ?>">
						<?php echo rhm_get_icon( 'chevron', 'size-5 -rotate-90' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?>
					</button>
				</div>
			<?php endif; ?>
		</div>

		<div class="swiper -mr-6">
			<div class="swiper-wrapper">
				<?php foreach ( $rhm_items as $rhm_item ) : ?>
					<?php
					$rhm_hotline = trim( (string) ( $rhm_item['hotline'] ?? '' ) );
					$rhm_map_url = (string) ( $rhm_item['map_url'] ?? '' );
					?>
					<div class="swiper-slide flex h-auto w-[80%] pr-6 sm:w-1/2 md:w-1/3 lg:w-1/4">
						<article class="flex w-full flex-col rounded-xl border border-thread bg-white p-3 pb-5">
							<div class="c-media aspect-[4/3]">
								<?php
								echo wp_get_attachment_image(
									$rhm_item['image'],
									'full',
									false,
									array(
										'class'    => 'absolute inset-0 size-full object-cover',
										'alt'      => $rhm_item['name'],
										'sizes'    => $rhm_sizes,
										'loading'  => 'lazy',
										'decoding' => 'async',
									)
								);
								?>
							</div>
							<div class="flex flex-1 flex-col px-2 pt-4 wrap-anywhere">
								<h3 class="c-h3"><?php echo esc_html( $rhm_item['name'] ); ?></h3>
								<p class="mt-2 text-base leading-relaxed">
									<span class="sr-only"><?php esc_html_e( 'Địa chỉ:', 'themeranghammatsgcantho' ); ?> </span><?php echo nl2br( esc_html( $rhm_item['address'] ), false ); ?>
								</p>
								<?php if ( '' !== $rhm_hotline ) : ?>
									<p class="mt-2">
										<a class="text-lg font-bold text-ink tabular-nums hover:text-primary" href="<?php echo esc_url( rhm_get_tel_href( $rhm_hotline ) ); ?>">
											<span class="sr-only"><?php esc_html_e( 'Gọi', 'themeranghammatsgcantho' ); ?> </span><?php echo esc_html( $rhm_hotline ); ?>
										</a>
									</p>
								<?php endif; ?>
								<?php if ( '' !== $rhm_map_url ) : ?>
									<p class="mt-auto pt-4">
										<a class="c-link" href="<?php echo esc_url( $rhm_map_url ); ?>"<?php echo rhm_external_link_attrs( $rhm_map_url ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static attributes. ?>>
											<?php esc_html_e( 'Chỉ đường', 'themeranghammatsgcantho' ); ?><span class="sr-only"> <?php /* translators: %s: tên chi nhánh. */ echo esc_html( sprintf( __( 'tới %s', 'themeranghammatsgcantho' ), $rhm_item['name'] ) ); ?></span>
										</a>
									</p>
								<?php endif; ?>
							</div>
						</article>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
</section>
