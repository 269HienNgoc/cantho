<?php
/**
 * WP-CLI: wp rhm-demo generate | landing | hero | distribute | delete | status
 *
 * @package rhm-demo-data
 */

defined( 'ABSPATH' ) || exit;

final class RHM_Demo_CLI {

	/**
	 * Tạo dữ liệu mẫu (1 bản gốc + bản sao).
	 *
	 * ## OPTIONS
	 *
	 * [--posts=<n>]
	 * : Tổng số bài viết. Mặc định 100.
	 *
	 * [--doctors=<n>]
	 * : Tổng số hồ sơ bác sĩ. Mặc định 100.
	 *
	 * [--fresh]
	 * : Xóa bài viết/bác sĩ mẫu cũ trước (giữ ảnh).
	 *
	 * [--landing]
	 * : Tạo luôn trang landing mẫu "Giới thiệu" (như lệnh wp rhm-demo landing).
	 *
	 * ## EXAMPLES
	 *
	 *     wp rhm-demo generate --posts=100 --doctors=100 --fresh
	 */
	public function generate( array $args, array $assoc ): void {
		$generator = new RHM_Demo_Generator( static fn( string $m ) => WP_CLI::log( $m ) );
		try {
			if ( WP_CLI\Utils\get_flag_value( $assoc, 'fresh', false ) ) {
				WP_CLI::log( sprintf( 'Đã xóa %d bài/hồ sơ mẫu cũ.', $generator->delete_content() ) );
			}
			$r = $generator->generate( absint( $assoc['posts'] ?? 100 ), absint( $assoc['doctors'] ?? 100 ) );
			if ( WP_CLI\Utils\get_flag_value( $assoc, 'landing', false ) ) {
				$generator->landing();
			}
		} catch ( Throwable $e ) {
			WP_CLI::error( $e->getMessage() );
		}
		WP_CLI::success( sprintf( '%d bài viết, %d hồ sơ bác sĩ, %d ảnh — %s giây.', $r['posts'], $r['doctors'], $r['images'], $r['seconds'] ) );
	}

	/**
	 * Tạo (hoặc ghi đè về mặc định) trang landing mẫu "Giới thiệu (dữ liệu mẫu)" đủ mọi section.
	 *
	 * ## EXAMPLES
	 *
	 *     wp rhm-demo landing
	 */
	public function landing(): void {
		try {
			$r = ( new RHM_Demo_Generator( static fn( string $m ) => WP_CLI::log( $m ) ) )->landing();
		} catch ( Throwable $e ) {
			WP_CLI::error( $e->getMessage() );
		}
		WP_CLI::success( sprintf( 'Trang landing mẫu #%d — %s (%s giây).', $r['id'], $r['url'], $r['seconds'] ) );
	}

	/**
	 * Xóa toàn bộ dữ liệu mẫu (bài viết, bác sĩ, ảnh, term mẫu không còn dùng).
	 *
	 * [--yes]
	 * : Không hỏi lại.
	 */
	public function delete( array $args, array $assoc ): void {
		WP_CLI::confirm( 'Xóa toàn bộ dữ liệu mẫu?', $assoc );
		$r = ( new RHM_Demo_Generator() )->delete();
		WP_CLI::success( sprintf( 'Đã xóa %d bài/hồ sơ, %d ảnh, %d term.', $r['posts'], $r['images'], $r['terms'] ) );
		if ( $r['kept_terms'] ) {
			WP_CLI::warning( 'Giữ lại term đang dùng trong menu/bài thật: ' . implode( ', ', $r['kept_terms'] ) . '. Gỡ khỏi menu rồi chạy lại để dọn hết.' );
		}
	}

	/**
	 * Tạo ảnh trang chủ (Hero, Dịch vụ nổi bật, Vì sao chọn) và gán vào các ô ảnh còn trống của Tùy biến.
	 *
	 * [--overwrite]
	 * : Ghi đè ô đang có ảnh.
	 */
	public function hero( array $args, array $assoc ): void {
		try {
			$r = ( new RHM_Demo_Generator( static fn( string $m ) => WP_CLI::log( $m ) ) )->hero( (bool) WP_CLI\Utils\get_flag_value( $assoc, 'overwrite', false ) );
		} catch ( Throwable $e ) {
			WP_CLI::error( $e->getMessage() );
		}
		WP_CLI::success( $r['assigned'] ? 'Đã gán: ' . implode( ', ', $r['assigned'] ) . '.' : 'Đã tạo ảnh; các ô đã có ảnh nên chưa gán (dùng --overwrite).' );
	}

	/**
	 * Tạo 10 chuyên mục mẫu (nếu thiếu) và rải đều bài viết mẫu hiện có vào đó.
	 */
	public function distribute(): void {
		$r = ( new RHM_Demo_Generator() )->distribute();
		foreach ( $r as $name => $count ) {
			WP_CLI::log( sprintf( '%-22s %d bài', $name, $count ) );
		}
		WP_CLI::success( sprintf( 'Đã rải bài viết mẫu vào %d chuyên mục.', count( $r ) ) );
	}

	/** Đếm dữ liệu mẫu hiện có. */
	public function status(): void {
		$c = RHM_Demo_Generator::counts();
		WP_CLI::log( sprintf( 'Bài viết: %d · Bác sĩ: %d · Trang landing: %d · Ảnh: %d', $c['posts'], $c['doctors'], $c['pages'], $c['images'] ) );
	}
}
